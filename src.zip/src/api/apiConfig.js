
const apiConfig = {
    API_BASE_URL:"https://rawady.brainsoftsolutions.com/api/",
    IMAGE_BASE_URL:"https://rawady.brainsoftsolutions.com/",
    revalidateTime:60
};

export default apiConfig;


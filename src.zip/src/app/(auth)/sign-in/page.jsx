
import SignIn from "@/Components/Auth/SignIn/SignIn";
import FullScreenLoader from "@/Components/Shared/FullScreenLoader/FullScreenLoader";

const SignInPage = () => {


    return(
        <>
            {/*<FullScreenLoader/>*/}
        <SignIn/>
        </>
    )
}
export  default SignInPage

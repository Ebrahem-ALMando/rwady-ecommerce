export const movingProducts=[
    {
        id: 1,
        main_img: "/images/Products/p1.jpeg",
        name: "كونير مكواة بخار محمولة للملابس - بخار كهربائي",
        finalPrice: "20,258 IQD",
    },
    {
        id: 2,
        main_img: "/images/Products/p2.jpeg",
        name: "شاشة 24 بوصة فل HD مع تقنية حماية العين",
        finalPrice: "35,900 IQD",
    },
    {
        id: 3,
        main_img: "/images/Products/p3.jpeg",
        name: "جاكيت شتوي فاخر بتصميم أنيق",
        finalPrice: "15,750 IQD",
    },
    {
        id: 4,
        main_img: "/images/Products/p4.jpeg",
        name: "مجموعة حقائب سفر أنيقة مقاومة للماء",
        finalPrice: "42,500 IQD",
    },
    {
        id: 5,

        main_img: "/images/Products/p1.jpeg",
        name: "سماعات لاسلكية بجودة صوت عالية",
        finalPrice: "18,900 IQD",
    },
]
export const Carts=[
    {
        img:"./images/Shopping/img.png",
        title:'بريتيجاردن بلوفر كاجوال كبير الحجم بقبة دائرية بدون طوق واكمام طويلة للنساء، بلوزة محبوكة مكتنزة',
        brand:"trendyol  ماركة  ",
        price:"‏50,000 IQD",
        discount:'خصم 30%',
        oldPrice:'‏50,000 IQD',
        deliveryType:'توصيل مجانى',
        quenty:[
            { value: '1', label: '1' },
            { value: '2', label: '2' },
            { value: '3', label: '3' },
        ]
    },
    {
        img:"./images/Shopping/img.png",
        title:'بريتيجاردن بلوفر كاجوال كبير الحجم بقبة دائرية بدون طوق واكمام طويلة للنساء، بلوزة محبوكة مكتنزة',
        brand:"trendyol  ماركة  ",
        price:"‏50,000 IQD",
        discount:'خصم 30%',
        oldPrice:'‏50,000 IQD',
        deliveryType:'توصيل مجانى',
        quenty:[
            { value: '1', label: '1' },
            { value: '2', label: '2' },
            { value: '3', label: '3' },
        ]
    },
    {
        img:"./images/Shopping/img.png",
        title:'بريتيجاردن بلوفر كاجوال كبير الحجم بقبة دائرية بدون طوق واكمام طويلة للنساء، بلوزة محبوكة مكتنزة',
        brand:"trendyol  ماركة  ",
        price:"‏50,000 IQD",
        discount:'خصم 30%',
        oldPrice:'‏50,000 IQD',
        deliveryType:'توصيل مجانى',
        quenty:[
            { value: '1', label: '1' },
            { value: '2', label: '2' },
            { value: '3', label: '3' },
        ]
    },
    {
        img:"./images/Shopping/img.png",
        title:'بريتيجاردن بلوفر كاجوال كبير الحجم بقبة دائرية بدون طوق واكمام طويلة للنساء، بلوزة محبوكة مكتنزة',
        brand:"trendyol  ماركة  ",
        price:"‏50,000 IQD",
        discount:'خصم 30%',
        oldPrice:'‏50,000 IQD',
        deliveryType:'توصيل مجانى',
        quenty:[
            { value: '1', label: '1' },
            { value: '2', label: '2' },
            { value: '3', label: '3' },
        ]
    }
]
export const navLinks = [
    { href: "/section/categories", label: "الاقسام" },
    { href: "/collections/offers-list", label: "العروض/ التخفيضات" },
    { href: "/section/brands", label: "الماركات" },
    { href: "/section/groups", label: "المجموعات" },
    { href: "/collections/top-selling", label: "اكثر مبيعا" },
    { href: "/collections/recommend-list", label: "المميزة" }
];
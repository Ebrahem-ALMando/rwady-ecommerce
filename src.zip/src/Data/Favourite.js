export const favouriteProducts = [
    {
        id: 1,
        isDiscount: true,
        isFavorite:true,
        title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        images: ["/images/p2.png", "/images/p2.png", "/images/p2.png"],
        price: "20,258 IQD",
        oldPrice: "22,258 IQD",
        available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
        brand: "PHILIPS",
        colors:[
            '#FF6D41',
            '#625F50',
        ],
        remaining:'باقى 9 وحدات متبقية',
        time:'143H : 60 M : 55 S'
    },
    {
        id: 2,
        isDiscount: false,
        isFavorite:false,
        title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        images: [
            "/images/p1.png",
            "/images/p1.png",
            "/images/p1.png",],
        price: "20,258 IQD",
        oldPrice: "22,258 IQD",
        available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
        brand: "PHILIPS",
        colors:[
            '#E41E1E',
            '#008CFF',
            '#07AD5D',
            '#FEAF3F',
        ],
        remaining:'باقى 9 وحدات متبقية',
        time:'143H : 60 M : 55 S'
    },
    {
        id: 2,
        isDiscount: false,
        isFavorite:true,
        title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        images: ["/images/img_1.png", "/images/img_1.png", "/images/img_1.png"],
        price: "20,258 IQD",
        oldPrice: "22,258 IQD",
        available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
        brand: "PHILIPS",
        colors:[
            '#E41E1E',
            '#008CFF',
            '#07AD5D',
            '#FEAF3F',
        ],
        remaining:'باقى 9 وحدات متبقية',
        time:'143H : 60 M : 55 S'
    },
    {
        id: 2,
        isDiscount: true,
        isFavorite:false,
        title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        images: ["/images/img_1.png", "/images/img_1.png", "/images/img_1.png"],
        price: "20,258 IQD",
        oldPrice: "22,258 IQD",
        available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
        brand: "PHILIPS",
        colors:[
            '#E41E1E',
            '#008CFF',
            '#07AD5D',
            '#FEAF3F',
        ],
        remaining:'باقى 9 وحدات متبقية',
        time:'143H : 60 M : 55 S'
    }
    ,
    {
        id: 2,
        isDiscount: true,
        isFavorite:false,
        title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        images: ["/images/img_1.png", "/images/img_1.png", "/images/img_1.png"],
        price: "20,258 IQD",
        oldPrice: "22,258 IQD",
        available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
        brand: "PHILIPS",
        colors:[
            '#E41E1E',
            '#008CFF',
            '#07AD5D',
            '#FEAF3F',
        ],
        remaining:'باقى 9 وحدات متبقية',
        time:'143H : 60 M : 55 S'
    }
    ,
    {
        id: 2,
        isDiscount: true,
        isFavorite:false,
        title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        images: ["/images/img_1.png", "/images/img_1.png", "/images/img_1.png"],
        price: "20,258 IQD",
        oldPrice: "22,258 IQD",
        available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
        brand: "PHILIPS",
        colors:[
            '#E41E1E',
            '#07AD5D',
            '#FEAF3F',
        ],
        remaining:'باقى 9 وحدات متبقية',
        time:'143H : 60 M : 55 S'
    }
    ,
    {
        id: 2,
        isDiscount: true,
        isFavorite:false,
        title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        images: ["/images/img_1.png", "/images/img_1.png", "/images/img_1.png"],
        price: "20,258 IQD",
        oldPrice: "22,258 IQD",
        available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
        brand: "PHILIPS",
        colors:[
            '#E41E1E',
            '#008CFF',
        ],
        remaining:'باقى 9 وحدات متبقية',
        time:'143H : 60 M : 55 S'
    }
];
export const images = [
    { original: "/images/Products/p5.jpeg", thumbnail: "/images/Products/p5.jpeg" },
    { original: "/images/Shopping/img.png", thumbnail: "/images/Shopping/img.png" },
    { original: "/images/Shopping/img.png", thumbnail: "/images/Shopping/img.png" },
    { original: "/images/Shopping/img.png", thumbnail: "/images/Shopping/img.png" },
    { original: "/images/Shopping/img.png", thumbnail: "/images/Shopping/img.png" },
    { original: "/images/Shopping/img.png", thumbnail: "/images/Shopping/img.png" },
];
import Navbar from "@/Components/Header/Navbar";

const Header=()=>{
    return(
            <Navbar/>
    )
}
export default Header
// import styles from './HomePage.jsx.module.css';

const HomePage = (props) => {
    return (
        <div
            // className={styles.container}
        >

        </div>
    );
};

export default HomePage.jsx;


const apiConfig = {
    API_BASE_URL:"https://rwady-backend.ahmed-albakor.com/api/",
    IMAGE_BASE_URL:"https://rwady-backend.ahmed-albakor.com/",
    USER_IMAGE_BASE_URL:"https://rwady-backend.ahmed-albakor.com/storage/",

    revalidateTime:60
};

export default apiConfig;


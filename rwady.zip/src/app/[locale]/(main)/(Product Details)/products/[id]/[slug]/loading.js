import Loading from "@/Components/Shared/Loading/Loading";


export default function LoadingPage() {


return(
    <Loading/>
)


}

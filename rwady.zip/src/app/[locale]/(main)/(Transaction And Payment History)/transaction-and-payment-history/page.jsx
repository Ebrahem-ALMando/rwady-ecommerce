

import TransactionAndPaymentHistory from "@/Components/TransactionAndPaymentHistory/TransactionAndPaymentHistory";

const TransactionAndPaymentHistoryPage = (props) => {
    return(
        <>

            <TransactionAndPaymentHistory/>

        </>
    )
}
export default TransactionAndPaymentHistoryPage
    export const sizes = [
        { title: "XXL", isAvailable: true },
        { title: "XL", isAvailable: false },
        { title: "L", isAvailable: true },
        { title: "M", isAvailable: true },
        { title: "S", isAvailable: false },
    ];
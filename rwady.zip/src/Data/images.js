export const images = [
    { original: "/images/Products/p5.jpeg", thumbnail: "/images/Products/p5.jpeg" },
    { original: "/images/Shopping/blur-placeholder.png", thumbnail: "/images/Shopping/blur-placeholder.png" },
    { original: "/images/Shopping/blur-placeholder.png", thumbnail: "/images/Shopping/blur-placeholder.png" },
    { original: "/images/Shopping/blur-placeholder.png", thumbnail: "/images/Shopping/blur-placeholder.png" },
    { original: "/images/Shopping/blur-placeholder.png", thumbnail: "/images/Shopping/blur-placeholder.png" },
    { original: "/images/Shopping/blur-placeholder.png", thumbnail: "/images/Shopping/blur-placeholder.png" },
];
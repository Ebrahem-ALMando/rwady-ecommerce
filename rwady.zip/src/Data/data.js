export const category = [
    { id: 1, title: "ملابس سفلية", logo: "/images/blur-placeholder.png" },
    { id: 2, title: "أحذية", logo: "/images/img_1.png" },
    { id: 3, title: "ملابس رجالية", logo: "/images/img_1.png" },
    { id: 4, title: "عنوان 4", logo: "/images/img_1.png"  },
    { id: 5, title: "عنوان 5", logo: "/images/img_1.png" },
    { id: 6, title: "عنوان 6", logo: "/images/img_1.png" }
];
export const Brands = [
    { id: 1,  logo: "/images/Brands/1.png" },
    { id: 2,  logo: "/images/Brands/2.png" },
    { id: 3,  logo: "/images/Brands/3.png" },
    { id: 4,  logo: "/images/Brands/4.png"  },
    { id: 5,  logo: "/images/Brands/1.png" },
    { id: 6,  logo: "/images/Brands/2.png" }
];

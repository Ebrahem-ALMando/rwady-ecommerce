export const ratingList = [
    { id: 1, title: "الكل", quantity: 100, },
    {
        id: 2,
        productRating: 5,
        quantity: 100
    },
    {
        id: 3,
        productRating: 4,
        quantity: 50
    },
    {
        id: 4,
        productRating: 3,
        quantity: 75
    },
    {
        id: 5,
        productRating: 2,
        quantity: 40
    },
    {
        id: 6,
        productRating: 1,
        quantity: 20
    }
];

export const  staticSlides = [
    {
        id: 1,
        title: "اكتشف كل ما هو جديد",
        description: ".عـــــــــــــــــــــــروض على جميع المنتجات",
        img: "/Home/slider1.png",
    },
    {
        id: 2,
        title: "اكتشف كل ما هو جديد",
        description: ".عـــــــــــــــــــــــروض على جميع المنتجات.",
        img:"/Home/slider1.png",
    },
    {
        id: 3,
        title: "عروض لا تفوت",
        description: "!احصل على أفضل العروض اليوم",
        img: "/Home/slider1.png",
    },
];
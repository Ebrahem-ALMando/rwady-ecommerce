export const colors = [
    { id: 1, name: "الكل", quantity: 100 },
    {
        name: "أحمر",
        code: "#F55157",
        id: 2,
        quantity: 100
    },
    {
        name: "أخضر",
        code: "#00AF6C",
        id: 3,
        quantity: 150
    },
    {
        name: "أسود",
        code: "#1E1E1E",
        id: 4,
        quantity: 200
    },
    {
        name: "أزرق",
        code: "#0741AD",
        id: 5,
        quantity: 120
    },
    {
        name: "برتقالي",
        code: "#FFAF44",
        id: 6,
        quantity: 80
    },
    {
        name: "بنفسجي",
        code: "#9747FF",
        id: 7,
        quantity: 90
    },
    {
        name: "برتقالي فاتح",
        code: "#FF9C00",
        id: 8,
        quantity: 110
    }
];

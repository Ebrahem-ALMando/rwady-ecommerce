export const categories = [
    { id: 1, title: "الكل", quantity: 100 },
    { id: 2, title: "فساتين نسائية", quantity: 50 },
    { id: 3, title: "ملابس محجبات", quantity: 75 },
    { id: 4, title: "ملابس خروج", quantity: 40 },
    { id: 5, title: "ملابس المنزل", quantity: 60 },
    { id: 6, title: "ملابس سفلية", quantity: 30 },
    { id: 7, title: "ملابس علوية", quantity: 90 },
    { id: 8, title: "ملابس كاجوال", quantity: 80 },
    { id: 9, title: "معاطف", quantity: 20 },
    { id: 10, title: "ملابس داخلية", quantity: 35 },
    { id: 11, title: "ملابس سهرة", quantity: 25 },
    { id: 12, title: "بناطيل", quantity: 55 }
];

export const Brand = [
    { id: 1, title: "الكل", quantity: 100 },
    { id: 2, title: "ZARA", quantity: 50 },
    { id: 3, title: "BERESHKA", quantity: 75 },
    { id: 4, title: "DEFACTO", quantity: 40 },
    { id: 5, title: "PULL & PEAR", quantity: 60 },
    { id: 7, title: "AMERICAN", quantity: 90 },
    { id: 8, title: "PRETTYGARDEN", quantity: 80 },
    { id: 9, title: "LC WIKIKII", quantity: 20 },
    { id: 10, title: "Mango", quantity: 35 },
]

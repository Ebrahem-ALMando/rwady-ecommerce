export const products = [
    {
        id: 1,
        isDiscount: true,
        isFavorite:true,
        name: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        photos: [

            {
                "id": 14,
                "order": 0,
                "url": "/images/p2.png",
                },
            {
                "id": 14,
                "order": 0,
                "url": "/images/img_1.png",
            },
            {
                "id": 14,
                "order": 0,
                "url": "/images/p2.png",
            },
            ],

        finalPrice: "20,258 ",
        price: "22,258 ",
        available: "",
        brand: {
            "id": 10,
            "name": "PHILIPS",
            "logo": "https://rawady.brainsoftsolutions.com/public/uploads/brands/1744895002.webp"
        },
        colors: [
            {
                "id": 1,
                "name": "الاحمر",
                "code": "#E41E1E",
            },
            {
                "id": 2,
                "name": "الاحمر",
                "code": "#008CFF",
            },
            {
                "id": 3,
                "name": "الاحمر",
                "code": "#07AD5D",
            },
            {
                "id": 4,
                "name": "الاحمر",
                "code": "#FEAF3F",
            },

            ],

        quantity:' 9 ',
        discount_start: "2025-03-29T22:00:00.000000Z",
        discount_end: "2025-05-09T21:00:00.000000Z",
    },
    {
        id: 1,
        isDiscount: true,
        isFavorite:true,
        name: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        photos: [

            {
                "id": 14,
                "order": 0,
                "url": "/images/img_1.png",
            },
            {
                "id": 14,
                "order": 0,
                "url": "/images/img_1.png",
            },
            {
                "id": 14,
                "order": 0,
                "url": "/images/img_1.png",
            },
        ],
        finalPrice: "20,258 ",
        price: "22,258 ",
        available: "",
        brand: {
            "id": 10,
            "name": "PHILIPS",
            "logo": "https://rawady.brainsoftsolutions.com/public/uploads/brands/1744895002.webp"
        },
        colors: [
            {
                "id": 1,
                "name": "الاحمر",
                "code": "#E41E1E",
            },
            {
                "id": 2,
                "name": "الاحمر",
                "code": "#008CFF",
            },
            {
                "id": 3,
                "name": "الاحمر",
                "code": "#07AD5D",
            },
            {
                "id": 4,
                "name": "الاحمر",
                "code": "#FEAF3F",
            },

        ],

        quantity:' 9 ',
        discount_start: "2025-03-29T22:00:00.000000Z",
        discount_end: "2025-05-09T21:00:00.000000Z",
    },
    {
        id: 1,
        isDiscount: true,
        isFavorite:true,
        name: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
        photos: [

            {
                "id": 14,
                "order": 0,
                "url": "/images/p1.png",
            },
            {
                "id": 14,
                "order": 0,
                "url": "/images/p1.png",
            },
            {
                "id": 14,
                "order": 0,
                "url": "/images/p1.png",
            },
        ],
        finalPrice: "20,258 ",
        price: "22,258 ",
        available: "",
        brand: {
            "id": 10,
            "name": "PHILIPS",
            "logo": "https://rawady.brainsoftsolutions.com/public/uploads/brands/1744895002.webp"
        },
        colors: [
            {
                "id": 1,
                "name": "الاحمر",
                "code": "#E41E1E",
            },
            {
                "id": 2,
                "name": "الاحمر",
                "code": "#008CFF",
            },
            {
                "id": 3,
                "name": "الاحمر",
                "code": "#07AD5D",
            },
            {
                "id": 4,
                "name": "الاحمر",
                "code": "#FEAF3F",
            },

        ],

        quantity:' 9 ',
        discount_start: "2025-03-29T22:00:00.000000Z",
        discount_end: "2025-05-09T21:00:00.000000Z",
    },
    // {
    //     id: 2,
    //     isDiscount: false,
    //     isFavorite:false,
    //     title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
    //     images: [
    //         "/images/p1.png",
    //         "/images/p1.png",
    //         "/images/p1.png",],
    //     price: "20,258 IQD",
    //     oldPrice: "22,258 IQD",
    //     available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
    //     brand: "PHILIPS",
    //     colors:[
    //         '#E41E1E',
    //         '#008CFF',
    //         '#07AD5D',
    //         '#FEAF3F',
    //     ],
    //     remaining:'باقى 9 وحدات متبقية',
    //     time:'143H : 60 M : 55 S'
    // },
    // {
    //     id: 2,
    //     isDiscount: false,
    //     isFavorite:true,
    //     title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
    //     images: ["/images/img_1.png", "/images/img_1.png", "/images/img_1.png"],
    //     price: "20,258 IQD",
    //     oldPrice: "22,258 IQD",
    //     available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
    //     brand: "PHILIPS",
    //     colors:[
    //         '#E41E1E',
    //         '#008CFF',
    //         '#07AD5D',
    //         '#FEAF3F',
    //     ],
    //     remaining:'باقى 9 وحدات متبقية',
    //     time:'143H : 60 M : 55 S'
    // },
    // {
    //     id: 2,
    //     isDiscount: true,
    //     isFavorite:false,
    //     title: "زولاي كيتشن مسند ادوات مائدة من السيليكون - خالي من البيسفينول",
    //     images: ["/images/img_1.png", "/images/img_1.png", "/images/img_1.png"],
    //     price: "20,258 IQD",
    //     oldPrice: "22,258 IQD",
    //     available: "اشتري بالاقساط 5000 د.ع / شهر لمدة 10 اشهر",
    //     brand: "PHILIPS",
    //     colors:[
    //         '#E41E1E',
    //         '#008CFF',
    //         '#07AD5D',
    //         '#FEAF3F',
    //     ],
    //     remaining:'باقى 9 وحدات متبقية',
    //     time:'143H : 60 M : 55 S'
    // }
];
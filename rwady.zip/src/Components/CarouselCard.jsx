
const CarouselCard=()=>{
    return(
        <Carousel>
            <CarouselContent className="-ml-2 md:-ml-4">
                <CarouselItem className="pl-2 md:pl-4">...</CarouselItem>
                <CarouselItem className="pl-2 md:pl-4">...</CarouselItem>
                <CarouselItem className="pl-2 md:pl-4">...</CarouselItem>
            </CarouselContent>
        </Carousel>

    )
}